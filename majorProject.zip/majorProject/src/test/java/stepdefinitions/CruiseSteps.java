

package stepdefinitions;

import base.DriverManager;
import io.cucumber.java.AfterAll;
import io.cucumber.java.en.*;
import pages.CruisePage;
import reports.AllureReport;

import org.openqa.selenium.WebDriver;

public class CruiseSteps {

    WebDriver driver = DriverManager.driver; // assuming you have a Hooks class managing WebDriver
    CruisePage cruisePage=new CruisePage(driver);
    
    @AfterAll
    public static void tearDown() {
    	AllureReport.openAllureReport();
    }

    @Then("I continue to Cruises and select Royal Caribbean")
    public void i_continue_to_cruises_and_select_royal_caribbean() {
        cruisePage.openCruiseSectionAndSelectRoyalCaribbean();
    }

    
    @Then("I search for cruises and switch to the results tab")
    public void i_search_cruises_and_switch_tab() {
        cruisePage.searchCruisesAndSwitchTab();
    }
    
    

    @Then("I extract languages offered on the cruise")
    public void i_extract_languages_offered() {
        cruisePage.displayLanguagesOffered();
    }

    @Then("I display passengers, crew and launch year")
    public void i_display_passengers_crew_launch_year() {
        cruisePage.displayCruiseOverview();
    }
}
