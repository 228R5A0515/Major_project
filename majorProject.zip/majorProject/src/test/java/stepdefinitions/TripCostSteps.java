
package stepdefinitions;


import reports.AllureReport;

import base.DriverManager;
import io.cucumber.java.AfterAll;
import io.cucumber.java.en.*;
import pages.Cruise;
import pages.CruisePage;
import pages.HolidayHomePage;
import pages.Home;
import utilities.ExcelUtilities;

import java.io.IOException;

import org.openqa.selenium.WebDriver;

	

		public class TripCostSteps {

		    WebDriver driver = DriverManager.driver;
		    //HolidayHomePage homePage = new HolidayHomePage(driver);
		    Home homePage = new Home(driver);
		    Cruise cruisePage = new Cruise(driver);
		   // CruisePage cruisePage = new CruisePage(driver);
		    ExcelUtilities excel = new ExcelUtilities();
		    
		    @AfterAll
		    public static void tearDown() {
		    	AllureReport.openAllureReport();
		    }
		    
		    @Given("I navigate to the Nairobi vacation rentals page")
		    public void i_navigate_to_nairobi_rentals() {
		        homePage.launchSite();
		    }

		    @When("I search for 4-person homes in Nairobi from tomorrow for 5 nights")
		    public void i_search_holiday_homes() {

           try {
            String city = excel.getCityName();       //  Read from Excel
            int guests = 4;                          //  Read from Excel
            homePage.searchHomes(city, guests);      //  Use in test
               } catch (IOException e) {
            System.out.println("Error reading Excel data: " + e.getMessage());
        }

		    }
		    
		    @When("I apply filter for elevator or lift access")
		    public void i_apply_elevator_filter() throws InterruptedException {
		        homePage.filterByElevatorAccess(); // ✅ Apply filter first
		    }

		    @When("I sort the listings by highest traveler rating")
		    public void i_sort_by_traveler_rating() {
		        homePage.sortByTravelerRating();   // ✅ Then sort
		    }

		    

		    @Then("I extract top 3 holiday homes with total and per-night charges")
		    public void i_extract_hotel_details() {
		        homePage.extractTop3HomeDetails();
		    }
		}
