package reports;

import java.io.IOException;

public class AllureReport {
	 
    /**
     * Generates a clean Allure report and opens it using the configured command-line path.
     * This method assumes Allure CLI is properly installed and available at the specified location.
     */
    public static void openAllureReport() {
        try {
            // Step 1: Generate Allure report from target/allure-results
            ProcessBuilder generate = new ProcessBuilder(
                    "C:\\Users\\2430152\\Downloads\\allure-2.35.1\\allure-2.35.1\\bin\\allure.bat",
                    "generate", "target/allure-results", "-o", "target/allure-report", "--clean");
            generate.inheritIO(); // Optionally shows output in the console
            Process genProcess = generate.start();
            genProcess.waitFor(); // Wait until report generation is complete
 
            // Step 2: Open the generated Allure report in the browser
            ProcessBuilder open = new ProcessBuilder(
                    "C:\\Users\\2430152\\Downloads\\allure-2.35.1\\allure-2.35.1\\bin\\allure.bat",
                    "open", "target/allure-report");
            open.inheritIO();
            Process openProcess = open.start();
            openProcess.waitFor(); // Wait until browser opens
 
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}