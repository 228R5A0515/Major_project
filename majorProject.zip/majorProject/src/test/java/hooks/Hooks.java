

package hooks;

import org.openqa.selenium.WebDriver;

import utils.ScreenshotUtil;

import base.DriverManager;
import io.cucumber.java.After;
import io.cucumber.java.AfterStep;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;

public class Hooks {
    @Before
    public void setup() {
        DriverManager.initDriver();
    }

    @After
    public void tearDown() {
        DriverManager.quitDriver();
    }
    
//    @AfterStep
//    public void takeScreenshotAfterStep(Scenario scenario) {
//        WebDriver driver = DriverManager.getDriver();
//        String scenarioName = scenario.getName().replaceAll(" ", "_");
//        ScreenshotUtil.captureScreenshot(driver, scenarioName);
//    }
}
