package utilities;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



public class ExcelUtilities {

    public String getCityName() throws IOException {
        FileInputStream file = new FileInputStream(System.getProperty("user.dir") + "\\Excel-Input\\input.xlsx");
        XSSFWorkbook workbook = new XSSFWorkbook(file);
        XSSFSheet sheet = workbook.getSheet("Sheet1");

        Row row = sheet.getRow(1); // Row index starts from 0
        Cell cell = row.getCell(0); // Column index starts from 0
        String cityName = cell.getStringCellValue();

        workbook.close();
        file.close();
        return cityName;
    }


public void writeHotelDataToExcel(java.util.List<String[]> hotelData) {
    String filePath = System.getProperty("user.dir") + "\\Excel-Input\\output.xlsx";

    try (XSSFWorkbook workbook = new XSSFWorkbook()) {
        XSSFSheet sheet = workbook.createSheet("Top 3 Hotels");

        // Header row
        Row header = sheet.createRow(0);
        header.createCell(0).setCellValue("Hotel Name");
        header.createCell(1).setCellValue("Total Price");
        header.createCell(2).setCellValue("Price Per Night");

        // Data rows
        for (int i = 0; i < hotelData.size(); i++) {
            Row row = sheet.createRow(i + 1);
            row.createCell(0).setCellValue(hotelData.get(i)[0]);
            row.createCell(1).setCellValue(hotelData.get(i)[1]);
            row.createCell(2).setCellValue(hotelData.get(i)[2]);
        }

        // Write to file
        try (FileOutputStream out = new FileOutputStream(filePath)) {
            workbook.write(out);
            System.out.println("Hotel data written to Excel successfully.");
        }

    } catch (IOException e) {
        System.out.println("Error writing to Excel: " + e.getMessage());
    }
}}


//C:\Users\2430017\Downloads\ExCucumber\ExCucumber\Excel-Input\input.xlsx