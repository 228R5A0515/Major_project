package utils;
 
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
 
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.Date;
 
public class ScreenshotUtil {
 
    public static void captureScreenshot(WebDriver driver, String fileNamePrefix) {
        File srcFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String destPath = "screenshots/" + fileNamePrefix + "_" + timestamp + ".png";
 
        File screenshotsDir = new File("screenshots");
        if (!screenshotsDir.exists()) {
            screenshotsDir.mkdirs();
        }
 
        try {
            Files.copy(srcFile.toPath(), new File(destPath).toPath());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
 