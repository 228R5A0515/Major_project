package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import utilities.ExcelUtilities;

import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class Home {

    private final WebDriver driver;
    private final WebDriverWait wait;
    private final String BASE_URL = "https://www.tripadvisor.in";
    
    // Constant for human-like delay (1 second)
    private static final long HUMAN_LIKE_DELAY = 1000; 

    // --- Page Locators using @FindBy ---
    @FindBy(xpath = "//*[contains(text(),'Verification Required')]")
    private List<WebElement> captchaCheck;

    @FindBy(xpath = "//button[contains(@aria-label,'Close')]")
    private WebElement closeAssistantPopup;
    
    @FindBy(xpath = "//*[contains(text(),'Holiday Homes')]")
    private WebElement holidayHomesTab;

    @FindBy(xpath = "//*[normalize-space(text())='Search']")
    private WebElement searchButton;
    
    @FindBy(xpath = "//input[@type='search' or @title='Search']") 
    private WebElement locationInput;

    @FindBy(xpath = "//a[@href='/VacationRentals-g294207-Reviews-Nairobi-Vacation_Rentals.html' and text()='Holiday Homes']")
    private WebElement holidayHomesLinkForLocation;

    @FindBy(xpath = "//button[@aria-label='Enter the date.']")
    private WebElement checkInButton;

    @FindBy(xpath = "//div[contains(text(),'Guests')]")
    private WebElement guestToggle;

    @FindBy(xpath = "//button[@data-automation='increaseAdults']")
    private WebElement increaseAdultsButton;

    @FindBy(xpath = "//button[@data-automation='applyGuests']")
    private WebElement applyGuestsButton;
    
    @FindBy(xpath = "//h3[text()='Amenities']")
    private WebElement amenitiesHeader;

    @FindBy(xpath = "//button[.//span[text()='Show all']]")
    private List<WebElement> showAllAmenitiesButton; 

    @FindBy(xpath = "//span[contains(text(),'Elevator/Lift access')]/ancestor::label")
    private WebElement elevatorAccessLabel;
    
    @FindBy(xpath = "//button[.//span[text()='Apply']]")
    private WebElement applyFilterButton;

    @FindBy(xpath = "//button[contains(@aria-label,'Sort:')]")
    private WebElement sortDropdown;

    @FindBy(xpath = "//span[@data-testid='menuitem' and .//span[text()='# of reviews']]")
    private WebElement reviewsSortOption;
    
    @FindBy(css = "h2.biGQs._P.SewaP.alXOW.oCpZu.GzNcM.nvOhm.UTQMg.ZTpaU.OgHoE")
    private List<WebElement> hotelNames;

    @FindBy(css = "div.biGQs._P.VImYz.KeZJf")
    private List<WebElement> perNightPrices;

    @FindBy(xpath = "//div[contains(@class, 'biGQs') and contains(@class, 'VImYz') and contains(@class, 'qWPrE')]")
    private List<WebElement> totalPrices;


    // --- Constructor ---

    public Home(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        PageFactory.initElements(driver, this); 
    }

    // --- Action Methods ---

    public void launchSite() {
        driver.get(BASE_URL);
        driver.manage().window().maximize();

        // 1. CAPTCHA Check
        if (!captchaCheck.isEmpty()) {
            System.out.println("CAPTCHA detected. Please solve it manually.");
            try {
                Thread.sleep(20000); 
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }

        // 2. AI assistant popup close
        try {
            wait.until(ExpectedConditions.elementToBeClickable(closeAssistantPopup)).click();
            System.out.println("AI assistant popup closed.");
            try { Thread.sleep(HUMAN_LIKE_DELAY); } catch (InterruptedException ignored) {} // Delay
        } catch (TimeoutException e) {
            System.out.println("AI assistant popup not found or already closed.");
        }

        // 3. Click Holiday Homes Tab
        try {
            wait.until(ExpectedConditions.elementToBeClickable(holidayHomesTab)).click();
            System.out.println("Clicked on holiday homes tab.");
            try { Thread.sleep(HUMAN_LIKE_DELAY); } catch (InterruptedException ignored) {} // Delay
        } catch (TimeoutException e) {
            System.out.println("Holiday Homes tab not found: " + e.getMessage());
        }
    }

    public void searchHomes(String location, int guests) {
        try {
            // 1. Click Search button to open search modal/bar
            wait.until(ExpectedConditions.elementToBeClickable(searchButton)).click();
            try { Thread.sleep(HUMAN_LIKE_DELAY); } catch (InterruptedException ignored) {} // Delay

            // 2. Enter Location
            WebElement input = wait.until(ExpectedConditions.elementToBeClickable(locationInput));
            input.clear();
            input.sendKeys(location);
            try { Thread.sleep(HUMAN_LIKE_DELAY / 2); } catch (InterruptedException ignored) {} // Typing delay
            input.sendKeys(Keys.ENTER);
            System.out.println("Location entered: " + location);
            try { Thread.sleep(HUMAN_LIKE_DELAY); } catch (InterruptedException ignored) {} // Delay

            // 3. Click Holiday Homes link for the specific location
            wait.until(ExpectedConditions.elementToBeClickable(holidayHomesLinkForLocation)).click();
            System.out.println("Clicked Holiday Homes link for " + location + ".");
            try { Thread.sleep(HUMAN_LIKE_DELAY * 2); } catch (InterruptedException ignored) {} // Delay for page load

            // 4. Select Dates
            selectCheckInAndCheckOutDates();

            // 5. Select Guests
            selectGuests(guests);

        } catch (Exception e) {
            System.out.println("Search failed: " + e.getMessage());
        }
    }
    
    private void selectCheckInAndCheckOutDates() {
        try {
            // Step 1: Open Check-In calendar
            wait.until(ExpectedConditions.elementToBeClickable(checkInButton)).click();
            System.out.println("Check-In calendar opened.");
            try { Thread.sleep(HUMAN_LIKE_DELAY); } catch (InterruptedException ignored) {} // Delay

            // Step 2: Select Check-In Date (Tomorrow)
            LocalDate checkInDate = LocalDate.now().plusDays(1);
            String checkInLabel = checkInDate.format(DateTimeFormatter.ofPattern("d MMMM yyyy", Locale.ENGLISH));
            WebElement checkInCell = wait.until(ExpectedConditions.presenceOfElementLocated(
                    By.xpath("//*[@aria-label='" + checkInLabel + "']")));
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", checkInCell);
            System.out.println("Selected check-in date: " + checkInLabel);
            try { Thread.sleep(HUMAN_LIKE_DELAY); } catch (InterruptedException ignored) {} // Delay

            // Step 3: Select Check-Out Date (5 days after check-in)
            LocalDate checkOutDate = checkInDate.plusDays(5);
            String checkOutLabel = checkOutDate.format(DateTimeFormatter.ofPattern("d MMMM yyyy", Locale.ENGLISH));
            WebElement checkOutCell = wait.until(ExpectedConditions.presenceOfElementLocated(
                    By.xpath("//*[@aria-label='" + checkOutLabel + "']")));
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", checkOutCell);
            System.out.println("Selected check-out date: " + checkOutLabel);
            try { Thread.sleep(HUMAN_LIKE_DELAY); } catch (InterruptedException ignored) {} // Delay

        } catch (Exception e) {
            System.out.println("Date selection failed: " + e.getMessage());
        }
    }
    
    private void selectGuests(int targetGuests) throws InterruptedException {
        if (targetGuests < 1) {
            System.out.println("Guest count must be 1 or more. Skipping guest selection.");
            return;
        }

        // Click guest toggle
        wait.until(ExpectedConditions.elementToBeClickable(guestToggle)).click();
        Thread.sleep(HUMAN_LIKE_DELAY); // Delay

        // Wait for the increase button to be clickable
        wait.until(ExpectedConditions.elementToBeClickable(increaseAdultsButton));

        // Click to reach the target number of guests (assuming default is 2)
        int clicks = targetGuests - 2; 
        if (clicks > 0) {
            for (int i = 0; i < clicks; i++) {
                increaseAdultsButton.click();
                Thread.sleep(500); // Shorter pause between rapid clicks
            }
        }
        
        System.out.println("Guest count set to " + targetGuests + " adults.");
        Thread.sleep(HUMAN_LIKE_DELAY); // Delay

        // Apply guests
        wait.until(ExpectedConditions.elementToBeClickable(applyGuestsButton)).click();
        System.out.println("Guest selection applied.");
        Thread.sleep(HUMAN_LIKE_DELAY * 2); // Longer delay after applying settings
    }


    public void filterByElevatorAccess() {
        try {
            // Step 1: Scroll to Amenities section
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", amenitiesHeader);
            System.out.println("Scrolled to Amenities section.");
            Thread.sleep(HUMAN_LIKE_DELAY); // Delay

            // Step 2: Click "Show all" if present
            if (!showAllAmenitiesButton.isEmpty() && showAllAmenitiesButton.get(0).isDisplayed()) {
                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", showAllAmenitiesButton.get(0));
                System.out.println("Clicked 'Show all' to reveal full amenities.");
                Thread.sleep(HUMAN_LIKE_DELAY); // Delay 
            } else {
                System.out.println("'Show all' button not found or already expanded.");
            }

            // Step 3: Click the Elevator/Lift access filter
            wait.until(ExpectedConditions.elementToBeClickable(elevatorAccessLabel)).click();
            System.out.println("Selected Elevator/Lift access filter.");
            Thread.sleep(HUMAN_LIKE_DELAY); // Delay
            
            // Step 4: Apply filter
            wait.until(ExpectedConditions.elementToBeClickable(applyFilterButton)).click();
            System.out.println("Applied amenities filter.");
            Thread.sleep(HUMAN_LIKE_DELAY * 2); // Longer delay for results load
            
        } catch (Exception e) {
            System.out.println("Filter failed: " + e.getMessage());
        }
    }

    public void sortByTravelerRating() {
        try {
            // 1. Scroll and click Sort Dropdown
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", sortDropdown);
            Thread.sleep(HUMAN_LIKE_DELAY); // Delay after scroll
            wait.until(ExpectedConditions.elementToBeClickable(sortDropdown)).click();
            System.out.println("Sort dropdown clicked.");
            Thread.sleep(HUMAN_LIKE_DELAY); // Delay after click
            
            // 2. Select '# of reviews' option
            WebElement reviewsOption = wait.until(ExpectedConditions.elementToBeClickable(reviewsSortOption));
            
            new Actions(driver).moveToElement(reviewsOption).click().perform();
            
            System.out.println("Selected '# of reviews' sort option.");
            Thread.sleep(HUMAN_LIKE_DELAY * 4); // Very long delay for sorting/re-load
            
        } catch (Exception e) {
            System.out.println("Sort failed: " + e.getMessage());
        }
    }

    public void extractTop3HomeDetails() {
        try {
            // Wait for at least 3 elements to be present before extracting
            wait.until(ExpectedConditions.numberOfElementsToBeMoreThan(By.cssSelector("h2.biGQs"), 2));

            // ... (rest of the extraction logic remains the same) ...
            
            System.out.println("Hotels found: " + hotelNames.size());
            System.out.println("Per night prices found: " + perNightPrices.size());
            System.out.println("Total prices found: " + totalPrices.size());

            int count = Math.min(Math.min(hotelNames.size(), perNightPrices.size()), totalPrices.size());
            List<String[]> hotelData = new ArrayList<>();

            for (int i = 0; i < count && i < 3; i++) {
                String hotel = hotelNames.get(i).getText().trim();
                String perNight = perNightPrices.get(i).getText().trim();
                String total = totalPrices.get(i).getText().trim();

                System.out.println("Hotel " + (i + 1) + ": " + hotel);
                System.out.println("  → Price per night: " + perNight);
                System.out.println("  → Total price: " + total);
                System.out.println("----------------------------------");

                hotelData.add(new String[]{hotel, total, perNight});
            }

            ExcelUtilities excel = new ExcelUtilities();
            excel.writeHotelDataToExcel(hotelData);
            System.out.println("Top 3 hotel details written to Excel.");

        } catch (Exception e) {
            System.out.println("Data extraction and writing failed: " + e.getMessage());
        }
    }
}