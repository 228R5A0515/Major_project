


package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import java.time.Duration;
import java.util.*;

public class CruisePage {

    WebDriver driver;
    WebDriverWait wait;

    public CruisePage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

 

    public void openCruiseSectionAndSelectRoyalCaribbean() {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollTo(0, document.body.scrollHeight);");

        driver.findElement(By.xpath("//span[text()='Cruises']")).click();

        WebElement dropdownButton = wait.until(ExpectedConditions.presenceOfElementLocated(
            By.cssSelector("button[class='EVXMG _G f k Q2 u _u w Gn Z B2 BF Cq Ra _S wSSLS mrjkJ']")));
        js.executeScript("arguments[0].click();", dropdownButton);

        sleep(2000);
        driver.findElement(By.id("menu-item-17391487")).click(); // Royal Caribbean
        sleep(5000);
    }

    public void searchCruisesAndSwitchTab() {
        driver.findElement(By.xpath("//button[text()='Search']")).click();

        List<String> windowList = new ArrayList<>(driver.getWindowHandles());
        if (windowList.size() > 1) {
            driver.switchTo().window(windowList.get(1));
        }
    }

    public void displayLanguagesOffered() {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollTo(0, document.body.scrollHeight);");

        List<WebElement> lang = driver.findElements(By.className("ui_radio"));
        System.out.println("🌐 Languages Offered:");
        for (WebElement button : lang) {
            System.out.println("- " + button.getText());
        }
    }

    public void displayCruiseOverview() {
        try {
            WebElement element = driver.findElement(By.xpath("//h2[text()='Overview']"));
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
            sleep(2000);

            WebElement container = driver.findElement(By.className("szsLm"));
            System.out.println("🛳️ Cruise Overview:");
            System.out.println(container.getText());
        } catch (Exception e) {
            System.out.println("❌ Failed to extract cruise overview: " + e.getMessage());
        }
    }

    private void sleep(int millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException ignored) {}
    }



}
