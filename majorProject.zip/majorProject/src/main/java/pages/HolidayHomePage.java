package pages;


  

    import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.*;

import utilities.ExcelUtilities;

import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;


    public class HolidayHomePage {

        WebDriver driver;
        WebDriverWait wait;

        public HolidayHomePage(WebDriver driver) {
            this.driver = driver;
            this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        }
        
        public void launchSite() {
            driver.get("https://www.tripadvisor.in");
            driver.manage().window().maximize();
            
            try {
                List<WebElement> captchaCheck = driver.findElements(By.xpath("//*[contains(text(),'Verification Required')]"));
                if (!captchaCheck.isEmpty()) {
                    System.out.println("CAPTCHA detected. Please solve it manually.");
                    Thread.sleep(20000);
                }
            } catch (Exception e) {
                System.out.println("Error while checking CAPTCHA: " + e.getMessage());
            }

            
            try {
                // Wait for AI assistant popup and close it if present
                WebElement closePopup = wait.until(ExpectedConditions.presenceOfElementLocated(
                    By.xpath("//button[contains(@aria-label,'Close')]")));
                closePopup.click();
                System.out.println("AI assistant popup closed.");
            } catch (Exception e) {
                System.out.println("AI assistant popup not found or already closed.");
            }

            try {
            	WebElement holidayHomesTab = new WebDriverWait(driver, Duration.ofSeconds(10))
            		    .until(ExpectedConditions.elementToBeClickable(By.xpath("//*[contains(text(),'Holiday Homes')]")));
            		holidayHomesTab.click();
            		System.out.println("CLicked on holidayhomes");


            } catch (Exception e) {
                System.out.println("Holiday Homes tab not found: " + e.getMessage());
            }
        }

        public void searchHomes(String location, int guests) {
            try {
            	WebElement searchButton = new WebDriverWait(driver, Duration.ofSeconds(10))
            		    .until(ExpectedConditions.elementToBeClickable(By.xpath("//*[normalize-space(text())='Search']")));
            		searchButton.click();
            		WebElement locationInput = new WebDriverWait(driver, Duration.ofSeconds(10))
            			    .until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@type='search' or @title='Search']")));

            			locationInput.clear();
            			locationInput.sendKeys(location);
            			locationInput.sendKeys(Keys.ENTER);
            			System.out.println("Location entered: Nairobi");
            			
            			
            	
            			WebElement holidayHomesLink = new WebDriverWait(driver, Duration.ofSeconds(10))
            				    .until(ExpectedConditions.elementToBeClickable(
            				        By.xpath("//a[@href='/VacationRentals-g294207-Reviews-Nairobi-Vacation_Rentals.html' and text()='Holiday Homes']")));
            				holidayHomesLink.click();
            				System.out.println("Clicked Holiday Homes link.");
		
            				

            					// Step 1: Open Check-In calendar
            					WebElement checkInButton = wait.until(ExpectedConditions.elementToBeClickable(
            					    By.xpath("//button[@aria-label='Enter the date.']")));
            					checkInButton.click();
            					System.out.println("Check-In calendar opened.");

            					// Step 2: Select Check-In Date (Tomorrow)
            					LocalDate checkInDate = LocalDate.now().plusDays(1); // 25 Sept
            					String checkInLabel = checkInDate.format(DateTimeFormatter.ofPattern("d MMMM yyyy", Locale.ENGLISH));
            					WebElement checkInCell = wait.until(ExpectedConditions.presenceOfElementLocated(
            					    By.xpath("//*[@aria-label='" + checkInLabel + "']")));
            					((JavascriptExecutor) driver).executeScript("arguments[0].click();", checkInCell);
            					System.out.println("Selected check-in date: " + checkInLabel);

            					// Step 3: Select Check-Out Date (5 days after check-in)
            					LocalDate checkOutDate = checkInDate.plusDays(5); // 30 Sept
            					String checkOutLabel = checkOutDate.format(DateTimeFormatter.ofPattern("d MMMM yyyy", Locale.ENGLISH));
            					WebElement checkOutCell = wait.until(ExpectedConditions.presenceOfElementLocated(
            					    By.xpath("//*[@aria-label='" + checkOutLabel + "']")));
            					((JavascriptExecutor) driver).executeScript("arguments[0].click();", checkOutCell);
            					System.out.println("Selected check-out date: " + checkOutLabel);

            					// Step 4: Wait for both dates to reflect (optional)
            					wait.until(ExpectedConditions.textToBePresentInElementLocated(
            					    By.xpath("//div[contains(text(),'" + checkInDate.getDayOfMonth() + "')]"), String.valueOf(checkInDate.getDayOfMonth())));
            					wait.until(ExpectedConditions.textToBePresentInElementLocated(
            					    By.xpath("//div[contains(text(),'" + checkOutDate.getDayOfMonth() + "')]"), String.valueOf(checkOutDate.getDayOfMonth())));
            					System.out.println("Both dates reflected on page.");



                // Guest selection (if available)
                WebElement guestToggle = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Guests')]")));
                guestToggle.click();
                
                WebElement increaseButton = wait.until(ExpectedConditions.elementToBeClickable(
                	    By.xpath("//button[@data-automation='increaseAdults']")));

                	for (int i = 0; i < 2; i++) {
                	    increaseButton.click();
                	    Thread.sleep(500);
                	}
                	System.out.println("Guest count set to 4 adults.");

                	WebElement applyButton = new WebDriverWait(driver, Duration.ofSeconds(10))
                		    .until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@data-automation='applyGuests']")));
                		applyButton.click();
                		System.out.println("Guest selection applied.");
;
                
                

          

                // Date picker logic can be added here if calendar is interactive
            } catch (Exception e) {
                System.out.println("Search failed: " + e.getMessage());
            }
        }

        public void filterByElevatorAccess() {
        	// Step 1: Scroll to Amenities section
        	WebElement amenitiesHeader = new WebDriverWait(driver, Duration.ofSeconds(10))
        	    .until(ExpectedConditions.presenceOfElementLocated(By.xpath("//h3[text()='Amenities']")));
        	((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", amenitiesHeader);
        	System.out.println("Scrolled to Amenities section.");

        	// Step 2: Click "Show all" if present
        	try {
        	    WebElement showAllButton = driver.findElement(By.xpath("//button[.//span[text()='Show all']]"));
        	    if (showAllButton.isDisplayed()) {
        	        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", showAllButton);
        	        System.out.println("Clicked 'Show all' to reveal full amenities.");
        	        Thread.sleep(1000); // wait for animation
        	    }
        	} catch (Exception e) {
        	    System.out.println("'Show all' button not found or already expanded.");
        	}

        

        	// Step 4: Click the label that wraps the span
        	WebElement elevatorLabel = new WebDriverWait(driver, Duration.ofSeconds(10))
        	    .until(ExpectedConditions.elementToBeClickable(
        	        By.xpath("//span[contains(text(),'Elevator/Lift access')]/ancestor::label")));
        	((JavascriptExecutor) driver).executeScript("arguments[0].click();", elevatorLabel);
        	System.out.println("Selected Elevator/Lift access filter.");
        	
        	
        	WebElement applyFilterButton = wait.until(ExpectedConditions.elementToBeClickable(
        		    By.xpath("//button[.//span[text()='Apply']]")));
        		((JavascriptExecutor) driver).executeScript("arguments[0].click();", applyFilterButton);
        		System.out.println("Applied amenities filter.");

        }

        public void sortByTravelerRating() {
            try {
            	WebElement sortDropdown = new WebDriverWait(driver, Duration.ofSeconds(10))
            		    .until(ExpectedConditions.presenceOfElementLocated(
            		        By.xpath("//button[contains(@aria-label,'Sort:')]")));
            		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", sortDropdown);
            		Thread.sleep(500);
            		((JavascriptExecutor) driver).executeScript("arguments[0].click();", sortDropdown);
            		System.out.println("Sort dropdown clicked.");
            		
 

          
            		for (int i = 0; i < 10; i++) {
            		    try {
            		        WebElement reviewsOption = new WebDriverWait(driver, Duration.ofSeconds(2))
            		            .until(ExpectedConditions.presenceOfElementLocated(
            		                By.xpath("//span[@data-testid='menuitem' and .//span[text()='# of reviews']]")));
            		        new Actions(driver).moveToElement(reviewsOption).click().perform();
            		        System.out.println("Selected '# of reviews' sort option.");
            		        Thread.sleep(4000);
            		        
            		    } catch (Exception e) {
            		        ((JavascriptExecutor) driver).executeScript("window.scrollBy(0, 100);");
            		        Thread.sleep(500);
            		    }
            		}



            } catch (Exception e) {
                System.out.println("Sort failed: " + e.getMessage());
            }
        }

        public void extractTop3HomeDetails() {
            try {
                List<WebElement> hotelNames = driver.findElements(By.cssSelector(
                    "h2.biGQs._P.SewaP.alXOW.oCpZu.GzNcM.nvOhm.UTQMg.ZTpaU.OgHoE"
                ));

                List<WebElement> perNightPrices = driver.findElements(By.cssSelector(
                    "div.biGQs._P.VImYz.KeZJf"
                ));

                List<WebElement> totalPrices = driver.findElements(By.xpath(
                    "//div[contains(@class, 'biGQs') and contains(@class, 'VImYz') and contains(@class, 'qWPrE')]"
                ));

                System.out.println("Hotels found: " + hotelNames.size());
                System.out.println("Per night prices found: " + perNightPrices.size());
                System.out.println("Total prices found: " + totalPrices.size());

                int count = Math.min(Math.min(hotelNames.size(), perNightPrices.size()), totalPrices.size());
                List<String[]> hotelData = new ArrayList<>();

                for (int i = 0; i < count && i < 3; i++) {
                    String hotel = hotelNames.get(i).getText().trim();
                    String perNight = perNightPrices.get(i).getText().trim();
                    String total = totalPrices.get(i).getText().trim();

                    System.out.println("Hotel " + (i + 1) + ": " + hotel);
                    System.out.println("  → Price per night: " + perNight);
                    System.out.println("  → Total price: " + total);
                    System.out.println("----------------------------------");

                    hotelData.add(new String[]{hotel, total, perNight});
                }

                // ✅ Debug print to verify list contents
                System.out.println("Hotel data collected:");
                for (String[] data : hotelData) {
                    System.out.println("Hotel: " + data[0] + ", Total: " + data[1] + ", Per Night: " + data[2]);
                }

                // ✅ Write to Excel
                ExcelUtilities excel = new ExcelUtilities();
                excel.writeHotelDataToExcel(hotelData);

            } catch (Exception e) {
                System.out.println("Validation failed: " + e.getMessage());
            }
        }

        

        		

    }



