package pages;


import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import java.time.Duration;
import java.util.*;

public class Cruise {

    private final WebDriver driver;
    private final WebDriverWait wait;
    private final JavascriptExecutor js;
    
    // --- Page Locators using @FindBy ---

    // Element to find and click the 'Cruises' main navigation link/tab
    @FindBy(xpath = "//span[text()='Cruises']")
    private WebElement cruisesTab;

    // Dropdown button to select the cruise line (specific class names used in original code)
    @FindBy(css = "button[class='EVXMG _G f k Q2 u _u w Gn Z B2 BF Cq Ra _S wSSLS mrjkJ']")
    private WebElement cruiseLineDropdownButton;

    // Royal Caribbean menu item (ID used in original code, which is highly unstable)
    @FindBy(id = "menu-item-17391487")
    private WebElement royalCaribbeanOption; 
    
    // Generic 'Search' button
    @FindBy(xpath = "//button[text()='Search']")
    private WebElement searchButton;

    // Locators for languages offered (class name in original code)
    @FindBy(className = "ui_radio")
    private List<WebElement> languageRadioButtons;

    // Locator for the 'Overview' header (to scroll to)
    @FindBy(xpath = "//h2[text()='Overview']")
    private WebElement overviewHeader;

    // Locator for the main container holding the cruise overview text (class name in original code)
    @FindBy(className = "szsLm")
    private WebElement overviewContainer;


    // --- Constructor ---

    public Cruise(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        this.js = (JavascriptExecutor) driver;
        // Initialize WebElements defined with @FindBy annotations
        PageFactory.initElements(driver, this); 
    }

    // --- Action Methods ---

    public void openCruiseSectionAndSelectRoyalCaribbean() {
        // Scroll to the bottom (as per original logic)
        js.executeScript("window.scrollTo(0, document.body.scrollHeight);");
        sleep(1000);

        // Click the 'Cruises' tab
        wait.until(ExpectedConditions.elementToBeClickable(cruisesTab)).click();
        sleep(1000);

        // Click the cruise line dropdown button
        wait.until(ExpectedConditions.elementToBeClickable(cruiseLineDropdownButton));
        js.executeScript("arguments[0].click();", cruiseLineDropdownButton);
        sleep(2000);
        
        // Select Royal Caribbean
        // NOTE: The ID locator used here is highly likely to change. Consider a more stable XPath 
        // like `//div[text()='Royal Caribbean International']` if possible.
        wait.until(ExpectedConditions.elementToBeClickable(royalCaribbeanOption)).click(); 
        sleep(5000); // Long wait for page load after selection
    }

    public void searchCruisesAndSwitchTab() {
        // Click the search button
        wait.until(ExpectedConditions.elementToBeClickable(searchButton)).click();
        sleep(2000); // Wait for the new tab to open

        // Switch to the new tab/window
        List<String> windowList = new ArrayList<>(driver.getWindowHandles());
        if (windowList.size() > 1) {
            driver.switchTo().window(windowList.get(1));
            System.out.println("Switched to the new cruise search tab.");
        } else {
            System.out.println("Warning: New window/tab did not open.");
        }
    }

    public void displayLanguagesOffered() {
        // Scroll to the bottom
        js.executeScript("window.scrollTo(0, document.body.scrollHeight);");
        sleep(2000);

        System.out.println(" Languages Offered:");
        // Use the PageFactory-initialized List<WebElement>
        for (WebElement button : languageRadioButtons) {
            // It's safer to use getText() directly on the WebElement from PageFactory
            System.out.println("- " + button.getText()); 
        }
    }

    public void displayCruiseOverview() {
        try {
            // Scroll to the Overview header
            wait.until(ExpectedConditions.visibilityOf(overviewHeader));
            js.executeScript("arguments[0].scrollIntoView(true);", overviewHeader);
            sleep(2000);

            // Print the Overview container text
            // Note: A short wait for the container visibility might be necessary if it loads dynamically.
            wait.until(ExpectedConditions.visibilityOf(overviewContainer));
            System.out.println("🛳️ Cruise Overview:");
            System.out.println(overviewContainer.getText());
        } catch (Exception e) {
            System.out.println("❌ Failed to extract cruise overview. The element or its text might be missing: " + e.getMessage());
        }
    }

    /**
     * Helper method to pause execution in a human-like way.
     * @param millis time in milliseconds to sleep.
     */
    private void sleep(int millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException ignored) {
            Thread.currentThread().interrupt();
        }
    }
}